Arquivo zip gerado em: 19/12/2022 11:26:54 
Este arquivo contém os casos de teste cadastrados até o momento, disponibilizado pelo professor aos alunos.
Exercício: Trabalho Prático 2 - Tabela de notas